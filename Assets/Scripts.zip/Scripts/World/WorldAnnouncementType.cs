namespace AliveWorld.World
{
    public enum WorldAnnouncementType
    {
        None = 0,
        FireRiskHigh = 1,
        FoodPriceRising = 2,
        WaterContamination = 3,
        WinterComing = 4,
        BanditsSighted = 5
    }
}
