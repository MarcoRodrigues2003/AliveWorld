using UnityEngine;
using AliveWorld.Core;

namespace AliveWorld.Work
{
    /// Abstract manager logic for a Workplace:
    /// audits WorkInventory periodically and posts/updates tickets on WorkBoard.
    /// This is the "workplace is aware of its needs" part.
    [RequireComponent(typeof(WorkInventory), typeof(WorkBoard))]
    public sealed class WorkAudit : MonoBehaviour
    {
        [Header("Audit cadence (ticks)")]
        [Min(1)] public int auditEveryNTicks = 20; // with 20 TPS, ~1 second

        [Header("Ticket scope")]
        public TicketScope fetchScope = TicketScope.Public;

        [Header("Ticket tuning (fixed-point priority points)")]
        [Tooltip("Base priority units converted to points internally (100 points = 1.00).")]
        [Min(0)] public int fetchWaterBasePriorityUnits = 4;
        [Min(0)] public int fetchFoodBasePriorityUnits = 4;
        [Min(0)] public int fetchFuelBasePriorityUnits = 3;

        [Tooltip("Aging units per second converted to points/tick internally.")]
        [Min(0)] public int fetchWaterAgingUnitsPerSecond = 1;
        [Min(0)] public int fetchFoodAgingUnitsPerSecond = 1;
        [Min(0)] public int fetchFuelAgingUnitsPerSecond = 1;

        [Header("Requested quantities when low (units)")]
        [Min(1)] public int fetchWaterQuantity = 20;
        [Min(1)] public int fetchFoodQuantity = 15;
        [Min(1)] public int fetchFuelQuantity = 10;

        private WorkInventory _inv;
        private WorkBoard _board;
        private bool _subscribed;

        private void Awake()
        {
            _inv = GetComponent<WorkInventory>();
            _board = GetComponent<WorkBoard>();
        }

        private void OnEnable() => TrySubscribe();
        private void Start() => TrySubscribe();
        private void OnDisable() => TryUnsubscribe();

        private void TrySubscribe()
        {
            if (_subscribed) return;
            if (SimClock.Instance == null) return;

            SimClock.Instance.OnTick += HandleTick;
            _subscribed = true;
        }

        private void TryUnsubscribe()
        {
            if (!_subscribed) return;
            if (SimClock.Instance == null) { _subscribed = false; return; }

            SimClock.Instance.OnTick -= HandleTick;
            _subscribed = false;
        }

        private void HandleTick(int nowTick)
        {
            if (auditEveryNTicks <= 0) return;
            if ((nowTick % auditEveryNTicks) != 0) return;

            AuditWater(nowTick);
            AuditFood(nowTick);
            AuditFuel(nowTick);
        }

        private void AuditWater(int nowTick)
        {
            if (!_inv.IsWaterLow()) return;

            if (HasUnfinishedTicket(TicketKind.Fetch, ResourceKind.Water, fetchScope))
                return;

            var t = new BoardTicket
            {
                id = new TicketId(0), // board assigns
                kind = TicketKind.Fetch,
                resource = ResourceKind.Water,
                scope = fetchScope,
                quantity = fetchWaterQuantity,

                basePriorityPoints = fetchWaterBasePriorityUnits * SimTickConfig.PriorityPointsPerUnit,
                agingPriorityPointsPerTick = UnitsPerSecondToPointsPerTick(fetchWaterAgingUnitsPerSecond),
                createdAtTick = nowTick,

                state = TicketState.Open,
                reservedByCitizenId = BoardTicket.UnreservedCitizenId,
                reservedAtTick = 0,
                lastProgressTick = 0,
                notes = "WorkAudit: water low"
            };

            _board.AddTicket(ref t);
        }

        private void AuditFood(int nowTick)
        {
            if (!_inv.IsFoodLow()) return;

            if (HasUnfinishedTicket(TicketKind.Fetch, ResourceKind.Food, fetchScope))
                return;

            var t = new BoardTicket
            {
                id = new TicketId(0),
                kind = TicketKind.Fetch,
                resource = ResourceKind.Food,
                scope = fetchScope,
                quantity = fetchFoodQuantity,

                basePriorityPoints = fetchFoodBasePriorityUnits * SimTickConfig.PriorityPointsPerUnit,
                agingPriorityPointsPerTick = UnitsPerSecondToPointsPerTick(fetchFoodAgingUnitsPerSecond),
                createdAtTick = nowTick,

                state = TicketState.Open,
                reservedByCitizenId = BoardTicket.UnreservedCitizenId,
                reservedAtTick = 0,
                lastProgressTick = 0,
                notes = "WorkAudit: food low"
            };

            _board.AddTicket(ref t);
        }

        private void AuditFuel(int nowTick)
        {
            if (!_inv.IsFuelLow()) return;

            if (HasUnfinishedTicket(TicketKind.Fetch, ResourceKind.Fuel, fetchScope))
                return;

            var t = new BoardTicket
            {
                id = new TicketId(0),
                kind = TicketKind.Fetch,
                resource = ResourceKind.Fuel,
                scope = fetchScope,
                quantity = fetchFuelQuantity,

                basePriorityPoints = fetchFuelBasePriorityUnits * SimTickConfig.PriorityPointsPerUnit,
                agingPriorityPointsPerTick = UnitsPerSecondToPointsPerTick(fetchFuelAgingUnitsPerSecond),
                createdAtTick = nowTick,

                state = TicketState.Open,
                reservedByCitizenId = BoardTicket.UnreservedCitizenId,
                reservedAtTick = 0,
                lastProgressTick = 0,
                notes = "WorkAudit: fuel low"
            };

            _board.AddTicket(ref t);
        }

        private bool HasUnfinishedTicket(TicketKind kind, ResourceKind resource, TicketScope scope)
        {
            var tickets = _board.Tickets;
            for (int i = 0; i < tickets.Count; i++)
            {
                var t = tickets[i];
                if (t.kind == kind && t.resource == resource && t.scope == scope && t.state != TicketState.Done)
                    return true;
            }
            return false;
        }

        private int UnitsPerSecondToPointsPerTick(int unitsPerSecond)
        {
            // units/sec -> points/sec -> points/tick
            int pointsPerSecond = unitsPerSecond * SimTickConfig.PriorityPointsPerUnit;
            return Mathf.CeilToInt(pointsPerSecond / (float)SimTickConfig.TicksPerSecond);
        }
    }
}
