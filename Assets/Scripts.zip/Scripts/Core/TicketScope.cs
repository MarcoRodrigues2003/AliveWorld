namespace AliveWorld.Core
{
    // Who is allowed to claim this ticket.
    public enum TicketScope
    {
        FamilyOnly = 0,
        WorkplaceOnly = 1,
        Public = 2
    }
}
