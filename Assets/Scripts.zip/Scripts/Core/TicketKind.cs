namespace AliveWorld.Core
{
    // What type of work is requested.
    public enum TicketKind
    {
        Inspect = 0,
        Fetch = 1,
        Deliver = 2,
        Craft = 3,
        Repair = 4,
        Cook = 5,
        Clean = 6,
        Patrol = 7
    }
}
