using UnityEngine;
using AliveWorld.Core;

namespace AliveWorld.Home
{
    /// Abstract manager logic for a Home:
    /// audits HomeInventory periodically and posts/updates tickets on HomeBoard.
    /// This is the "house is aware of its needs" part.
    [RequireComponent(typeof(HomeInventory), typeof(HomeBoard))]
    public sealed class HomeAudit : MonoBehaviour
    {
        [Header("Audit cadence (ticks)")]
        [Min(1)] public int auditEveryNTicks = 20; // with 20 TPS, this is ~1 second

        [Header("Ticket tuning (fixed-point priority points)")]
        [Tooltip("Base priority units converted to points internally (100 points = 1.00).")]
        [Min(0)] public int fetchWaterBasePriorityUnits = 5;
        [Min(0)] public int fetchFoodBasePriorityUnits = 5;
        [Min(0)] public int fetchFuelBasePriorityUnits = 3;

        [Tooltip("Aging units per second converted to points/tick internally.")]
        [Min(0)] public int fetchWaterAgingUnitsPerSecond = 1;
        [Min(0)] public int fetchFoodAgingUnitsPerSecond = 1;
        [Min(0)] public int fetchFuelAgingUnitsPerSecond = 1;

        [Tooltip("Requested quantities when low (units).")]
        [Min(1)] public int fetchWaterQuantity = 20;
        [Min(1)] public int fetchFoodQuantity = 15;
        [Min(1)] public int fetchFuelQuantity = 10;


        private HomeInventory _inv;
        private HomeBoard _board;
        private bool _subscribed;

        private void Awake()
        {
            _inv = GetComponent<HomeInventory>();
            _board = GetComponent<HomeBoard>();
        }

        private void OnEnable()
        {
            TrySubscribe();
        }

        private void Start()
        {
            // Covers cases where SimClock.Instance wasn't ready during OnEnable.
            TrySubscribe();
        }

        private void OnDisable()
        {
            TryUnsubscribe();
        }

        private void TrySubscribe()
        {
            if (_subscribed) return;
            if (SimClock.Instance == null) return;

            SimClock.Instance.OnTick += HandleTick;
            _subscribed = true;
        }

        private void TryUnsubscribe()
        {
            if (!_subscribed) return;
            if (SimClock.Instance == null) { _subscribed = false; return; }

            SimClock.Instance.OnTick -= HandleTick;
            _subscribed = false;
        }

        private void HandleTick(int nowTick)
        {
            if (auditEveryNTicks <= 0) return;
            if ((nowTick % auditEveryNTicks) != 0) return;

            AuditWater(nowTick);
            AuditFood(nowTick);
            AuditFuel(nowTick);

            // Cleanup: remove done tickets occasionally
            _board.RemoveDoneTickets();
        }

        private void AuditWater(int nowTick)
        {
            if (!_inv.IsWaterLow())
                return;

            // If a Fetch/Water ticket already exists (Open or Reserved/InProgress), do nothing.
            // We want the ticket to "age" rather than spawning duplicates.
            if (HasAnyTicket(TicketKind.Fetch, ResourceKind.Water, TicketScope.FamilyOnly))
                return;

            var t = new BoardTicket
            {
                id = new TicketId(0), // board will assign
                kind = TicketKind.Fetch,
                resource = ResourceKind.Water,
                scope = TicketScope.FamilyOnly,
                quantity = fetchWaterQuantity,

                basePriorityPoints = fetchWaterBasePriorityUnits * SimTickConfig.PriorityPointsPerUnit,
                agingPriorityPointsPerTick = UnitsPerSecondToPointsPerTick(fetchWaterAgingUnitsPerSecond),

                createdAtTick = nowTick,

                state = TicketState.Open,
                reservedByCitizenId = BoardTicket.UnreservedCitizenId,
                notes = "HomeAudit: water low"
            };

            _board.AddTicket(ref t);
        }

        private void AuditFood(int nowTick)
        {
            if (!_inv.IsFoodLow())
                return;

            if (HasAnyTicket(TicketKind.Fetch, ResourceKind.Food, TicketScope.FamilyOnly))
                return;

            var t = new BoardTicket
            {
                id = new TicketId(0),
                kind = TicketKind.Fetch,
                resource = ResourceKind.Food,
                scope = TicketScope.FamilyOnly,
                quantity = fetchFoodQuantity,

                basePriorityPoints = fetchFoodBasePriorityUnits * SimTickConfig.PriorityPointsPerUnit,
                agingPriorityPointsPerTick = UnitsPerSecondToPointsPerTick(fetchFoodAgingUnitsPerSecond),

                createdAtTick = nowTick,

                state = TicketState.Open,
                reservedByCitizenId = BoardTicket.UnreservedCitizenId,
                notes = "HomeAudit: food low"
            };

            _board.AddTicket(ref t);
        }

        private void AuditFuel(int nowTick)
        {
            if (!_inv.IsFuelLow())
                return;

            if (HasAnyTicket(TicketKind.Fetch, ResourceKind.Fuel, TicketScope.FamilyOnly))
                return;

            var t = new BoardTicket
            {
                id = new TicketId(0),
                kind = TicketKind.Fetch,
                resource = ResourceKind.Fuel,
                scope = TicketScope.FamilyOnly,
                quantity = fetchFuelQuantity,

                basePriorityPoints = fetchFuelBasePriorityUnits * SimTickConfig.PriorityPointsPerUnit,
                agingPriorityPointsPerTick = UnitsPerSecondToPointsPerTick(fetchFuelAgingUnitsPerSecond),

                createdAtTick = nowTick,

                state = TicketState.Open,
                reservedByCitizenId = BoardTicket.UnreservedCitizenId,
                notes = "HomeAudit: fuel low"
            };

            _board.AddTicket(ref t);
        }

        private bool HasAnyTicket(TicketKind kind, ResourceKind resource, TicketScope scope)
        {
            // checks any state except Done (because Done tickets are removable)
            var list = _board.Tickets;
            for (int i = 0; i < list.Count; i++)
            {
                var t = list[i];
                if (t.kind == kind && t.resource == resource && t.scope == scope && t.state != TicketState.Done)
                    return true;
            }
            return false;
        }

        private int UnitsPerSecondToPointsPerTick(int unitsPerSecond)
        {
            // units/sec -> points/sec -> points/tick
            // points/sec = unitsPerSecond * 100
            // points/tick = points/sec / ticksPerSecond
            int pointsPerSecond = unitsPerSecond * SimTickConfig.PriorityPointsPerUnit;
            return Mathf.CeilToInt(pointsPerSecond / (float)SimTickConfig.TicksPerSecond);
        }
    }
}
