using System;
using UnityEngine;
using AliveWorld.Core;
using AliveWorld.Home;
using AliveWorld.World;
using AliveWorld.Work;

namespace AliveWorld.Citizen
{
    /// Citizen visits local boards, reads available tickets, scores them, and reserves the best eligible one.
    /// This does NOT execute the ticket yet.
    [RequireComponent(typeof(CitizenIdentity), typeof(CitizenJobMemory))]
    public sealed class CitizenJobSeeker : MonoBehaviour
    {
        [Header("References (assign later)")]
        public HomeBoard[] readableHomeBoards;
        public WorkBoard[] readableWorkBoards;
        public WorldBlackboard worldBlackboard;     // global announcements

        [Header("Read behavior")]
        [Min(0f)] public float boardReadRadius = 1.5f;

        [Tooltip("How often we allow board-reading attempts (ticks).")]
        [Min(1)] public int attemptReadEveryNTicks = 20;

        private CitizenIdentity _id;
        private CitizenJobMemory _mem;

        private bool _subscribed;

        private void Awake()
        {
            _id = GetComponent<CitizenIdentity>();
            _mem = GetComponent<CitizenJobMemory>();
        }

        private void OnEnable() => TrySubscribe();
        private void Start() => TrySubscribe();
        private void OnDisable() => TryUnsubscribe();

        private void TrySubscribe()
        {
            if (_subscribed) return;
            if (SimClock.Instance == null) return;

            SimClock.Instance.OnTick += HandleTick;
            _subscribed = true;
        }

        private void TryUnsubscribe()
        {
            if (!_subscribed) return;
            if (SimClock.Instance == null) { _subscribed = false; return; }

            SimClock.Instance.OnTick -= HandleTick;
            _subscribed = false;
        }

        private void HandleTick(int nowTick)
        {
            if (_mem.hasTicket) return;

            bool hasHome = readableHomeBoards != null && readableHomeBoards.Length > 0;
            bool hasWork = readableWorkBoards != null && readableWorkBoards.Length > 0;
            if (!hasHome && !hasWork) return;
            if (attemptReadEveryNTicks <= 0) return;
            if ((nowTick % attemptReadEveryNTicks) != 0) return;

            TryReadAndReserveBestAcrossBoards(nowTick);
        }

        private bool IsNearBoard(Vector3 boardPos)
        {
            float dist = Vector3.Distance(transform.position, boardPos);
            return dist <= boardReadRadius;
        }

        private void TryReadAndReserveBestAcrossBoards(int nowTick)
        {
            long bestScore = long.MinValue;
            TicketId bestId = default;
            HomeBoard bestBoard = null;

            for (int b = 0; b < readableHomeBoards.Length; b++)
            {
                var board = readableHomeBoards[b];
                if (board == null) continue;

                // Knowledge constraint: must be near THIS board to read it.
                if (!IsNearBoard(board.transform.position))
                    continue;

                var tickets = board.Tickets;
                for (int i = 0; i < tickets.Count; i++)
                {
                    var t = tickets[i];

                    if (t.state != TicketState.Open)
                        continue;

                    // For now: only FamilyOnly from HomeBoards
                    if (t.scope != TicketScope.FamilyOnly)
                        continue;

                    long score = ScoreTicket(nowTick, t);
                    if (score > bestScore)
                    {
                        bestScore = score;
                        bestId = t.id;
                        bestBoard = board;
                    }
                }
            }

            if (bestBoard == null)
                return;

            if (bestBoard.TryReserve(bestId, _id.citizenId, nowTick))
            {
                // IMPORTANT: store the board object this ticket came from
                _mem.Set(bestId, bestBoard.gameObject);
            }
        }

        private long ScoreTicket(int nowTick, in BoardTicket ticket)
        {
            long aged = ticket.GetAgedPriorityPoints(nowTick);

            float worldMul = 1f;
            if (worldBlackboard != null)
                worldMul = worldBlackboard.GetWorldMultiplierFor(ticket);

            float personalMul = GetPersonalMultiplier(ticket.kind);

            double combined = aged * (double)worldMul * (double)personalMul;
            return (long)Math.Round(combined);
        }

        private float GetPersonalMultiplier(TicketKind kind)
        {
            return kind switch
            {
                TicketKind.Fetch => _id.fetchAffinity,
                TicketKind.Repair => _id.repairAffinity,
                TicketKind.Cook => _id.cookAffinity,
                TicketKind.Clean => _id.cleanAffinity,
                _ => 1f
            };
        }
    }
}
