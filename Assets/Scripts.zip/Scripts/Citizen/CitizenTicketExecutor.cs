using UnityEngine;
using AliveWorld.Core;
using AliveWorld.Home;
using AliveWorld.World;

namespace AliveWorld.Citizen
{
    /// Executes the currently reserved ticket.
    /// Supports multiple job sources by using CitizenJobMemory.ticketBoardObject.
    /// Supports multiple providers by querying ResourceProviderDirectory.
    /// Vertical slice: executes Fetch tickets for Food/Water/Fuel.
    [RequireComponent(typeof(CitizenIdentity), typeof(CitizenJobMemory), typeof(CitizenNavMover))]
    public sealed class CitizenTicketExecutor : MonoBehaviour
    {
        public enum ExecState
        {
            Idle = 0,
            GoToProvider = 1,
            PickupWait = 2,
            GoToHome = 3,
            DepositWait = 4
        }

        [Header("Execution tuning")]
        [Min(0f)] public float pickupWaitSeconds = 1.0f;
        [Min(0f)] public float depositWaitSeconds = 0.2f;
        [Header("Failure handling")]
        [Min(1)] public int maxTicksWithoutProgress = 200;

        [Header("Debug (read-only)")]
        [SerializeField] private ExecState state = ExecState.Idle;
        [SerializeField] private ResourceKind currentResource = ResourceKind.None;
        [SerializeField] private int carryAmount = 0;

        private CitizenIdentity _id;
        private CitizenJobMemory _mem;
        private CitizenNavMover _mover;

        private bool _subscribed;
        private float _waitTimer;

        private ResourceProvider _chosenProvider;

        // Active "job context" resolved from the board in memory
        private HomeBoard _activeHomeBoard;
        private HomeInventory _activeHomeInventory;

        private int _ticksWithoutProgress = 0;

        private void Awake()
        {
            _id = GetComponent<CitizenIdentity>();
            _mem = GetComponent<CitizenJobMemory>();
            _mover = GetComponent<CitizenNavMover>();
        }

        private void OnEnable() => TrySubscribe();
        private void Start() => TrySubscribe();
        private void OnDisable() => TryUnsubscribe();

        private void TrySubscribe()
        {
            if (_subscribed) return;
            if (SimClock.Instance == null) return;

            SimClock.Instance.OnTick += HandleTick;
            _subscribed = true;
        }

        private void TryUnsubscribe()
        {
            if (!_subscribed) return;
            if (SimClock.Instance == null) { _subscribed = false; return; }

            SimClock.Instance.OnTick -= HandleTick;
            _subscribed = false;
        }

        private void Update()
        {
            if (_waitTimer > 0f)
                _waitTimer -= Time.deltaTime;
        }

        private void HandleTick(int nowTick)
        {
            if (!_mem.hasTicket)
            {
                ResetExec();
                return;
            }

            // Tickets may come from multiple sources: use the board stored in memory.
            if (!ResolveBoardAndInventoryFromMemory())
                return;

            // Read authoritative ticket from that board
            if (!_activeHomeBoard.TryGetTicketById(_mem.ticketId, out var ticket, out _))
            {
                _mem.Clear();
                ResetExec();
                return;
            }

            _ticksWithoutProgress++;

            // Must be ours
            if (_ticksWithoutProgress > maxTicksWithoutProgress)
            {
                _activeHomeBoard.TryAbandon(ticket.id, _id.citizenId, nowTick, "Executor timeout (no progress)");
                _mem.Clear();
                ResetExec();
                return;
            }


            // Vertical slice: Fetch only
            if (ticket.kind != TicketKind.Fetch)
                return;

            switch (state)
            {
                case ExecState.Idle:
                    BeginFetch(ticket, nowTick);
                    break;

                case ExecState.GoToProvider:
                    if (_mover.IsAtTarget())
                    {
                        _mover.ConsumeArrival();
                        _activeHomeBoard.TouchProgress(ticket.id, _id.citizenId, nowTick, "Arrived at provider");
                        _ticksWithoutProgress = 0;

                        state = ExecState.PickupWait;
                        _waitTimer = pickupWaitSeconds;

                        // waiting is still "progress" (prevents timeout if waits get longer later)
                        _activeHomeBoard.TouchProgress(ticket.id, _id.citizenId, nowTick, "Waiting pickup");
                        _ticksWithoutProgress = 0;
                    }
                    break;

                case ExecState.PickupWait:
                    if (_waitTimer <= 0f)
                    {
                        carryAmount = (_chosenProvider != null) ? _chosenProvider.Take(ticket.quantity) : 0;

                        if (carryAmount <= 0)
                        {
                            _activeHomeBoard.TryAbandon(ticket.id, _id.citizenId, nowTick, "Provider returned 0");
                            _mem.Clear();
                            ResetExec();
                            return;
                        }

                        _activeHomeBoard.TouchProgress(ticket.id, _id.citizenId, nowTick, $"Picked up {carryAmount} {currentResource}");
                        _ticksWithoutProgress = 0;

                        state = ExecState.GoToHome;
                        _mover.SetTarget(_activeHomeBoard.transform.position);
                    }
                    break;

                case ExecState.GoToHome:
                    if (_mover.IsAtTarget())
                    {
                        _mover.ConsumeArrival();
                        _activeHomeBoard.TouchProgress(ticket.id, _id.citizenId, nowTick, "Arrived home");
                        _ticksWithoutProgress = 0;

                        state = ExecState.DepositWait;
                        _waitTimer = depositWaitSeconds;

                        _activeHomeBoard.TouchProgress(ticket.id, _id.citizenId, nowTick, "Waiting deposit");
                        _ticksWithoutProgress = 0;
                    }
                    break;

                case ExecState.DepositWait:
                    if (_waitTimer <= 0f)
                    {
                        DepositToHome(currentResource, carryAmount);

                        _activeHomeBoard.TouchProgress(ticket.id, _id.citizenId, nowTick, "Depositing");
                        _ticksWithoutProgress = 0;

                        bool completed = _activeHomeBoard.TryComplete(ticket.id, _id.citizenId,
                            $"Delivered {carryAmount} {currentResource}");

                        _mem.Clear();
                        ResetExec();

                        if (!completed)
                            Debug.LogWarning("CitizenTicketExecutor: deposit succeeded but ticket completion failed.");
                    }
                    break;
            }
        }

        private bool ResolveBoardAndInventoryFromMemory()
        {
            if (_mem.ticketBoardObject == null)
            {
                _mem.Clear();
                ResetExec();
                return false;
            }

            // For now: memory board object must be a HomeBoard.
            var hb = _mem.ticketBoardObject.GetComponent<HomeBoard>();
            if (hb == null)
            {
                Debug.LogWarning("CitizenTicketExecutor: ticketBoardObject has no HomeBoard.");
                _mem.Clear();
                ResetExec();
                return false;
            }

            _activeHomeBoard = hb;

            // Inventory located on same object or parents (supports flexible hierarchy)
            var inv = _mem.ticketBoardObject.GetComponentInParent<HomeInventory>();
            if (inv == null)
            {
                Debug.LogWarning("CitizenTicketExecutor: could not find HomeInventory for this board.");
                _mem.Clear();
                ResetExec();
                return false;
            }

            _activeHomeInventory = inv;
            return true;
        }

        private void BeginFetch(in BoardTicket ticket, int nowTick)
        {
            currentResource = ticket.resource;
            carryAmount = 0;
            _chosenProvider = null;

            _activeHomeBoard.TryStartWork(ticket.id, _id.citizenId, nowTick);
            _activeHomeBoard.TouchProgress(ticket.id, _id.citizenId, nowTick, "Started work");
            _ticksWithoutProgress = 0;

            if (ResourceProviderDirectory.Instance == null)
            {
                Debug.LogWarning("No ResourceProviderDirectory in scene. Cannot find providers.");
                _activeHomeBoard.TryAbandon(ticket.id, _id.citizenId, nowTick, "No ResourceProviderDirectory");
                _mem.Clear();
                ResetExec();
                return;
            }

            _chosenProvider = ResourceProviderDirectory.Instance.FindBestProvider(
                currentResource, ticket.quantity, transform.position);

            if (_chosenProvider == null)
            {
                Debug.LogWarning($"No provider can supply {ticket.quantity} of {currentResource}.");
                _activeHomeBoard.TryAbandon(ticket.id, _id.citizenId, nowTick, "No provider/stock");
                _mem.Clear();
                ResetExec();
                return;
            }

            state = ExecState.GoToProvider;
            _mover.SetTarget(_chosenProvider.transform.position);
        }

        private void DepositToHome(ResourceKind resource, int amount)
        {
            if (amount <= 0) return;

            switch (resource)
            {
                case ResourceKind.Water:
                    _activeHomeInventory.waterUnits += amount;
                    break;
                case ResourceKind.Food:
                    _activeHomeInventory.foodUnits += amount;
                    break;
                case ResourceKind.Fuel:
                    _activeHomeInventory.fuelUnits += amount;
                    break;
            }
        }

        private void ResetExec()
        {
            state = ExecState.Idle;
            currentResource = ResourceKind.None;
            carryAmount = 0;
            _waitTimer = 0f;
            _chosenProvider = null;
            _activeHomeBoard = null;
            _activeHomeInventory = null;
            _ticksWithoutProgress = 0;
        }
    }
}
